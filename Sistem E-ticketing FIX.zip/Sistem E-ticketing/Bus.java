
class Bus extends Transport {

    public Bus(String name, int kapasitas, double hargaTiket, int kecepatanMaksimum, String asal, String tujuan, String nomorKendaraan, String jadwalKeberangkatan, int durasiPerjalanan) {
        super(name, kapasitas, hargaTiket, kecepatanMaksimum, asal, tujuan, nomorKendaraan, jadwalKeberangkatan, durasiPerjalanan);
    }

    @Override
    public void displayInfoDetail() {
        System.out.println("Nama Bis: " + getNama());
        System.out.println("Kapasitas: " + getKapasitas() + " penumpang");
        System.out.println("Harga Tiket: " + Util.formatRupiah(getHargaTiket()));
        System.out.println("Kecepatan Maksimum: " + getKecepatanMaksimum() + " km/h");
        System.out.println("Asal: " + getAsal());
        System.out.println("Tujuan: " + getTujuan());
        System.out.println("Nomor Kendaraan: " + getNomorKendaraan());
        System.out.println("Jadwal Keberangkatan: " + getJadwalKeberangkatan());
        System.out.println("Durasi Perjalanan: " + getDurasiPerjalanan() + " menit");
    }

    @Override
    public void displayInfo() {
        System.out.println("Nomor Kendaraan: " + getNomorKendaraan());
        System.out.println(getNama() + " - (" + Util.formatRupiah(getHargaTiket()) + ")");
        System.err.println(getAsal() + " -> " + getTujuan());
        System.out.println("Berangkat pada " + getJadwalKeberangkatan());
        System.out.println();
    }

    @Override
    public void displaySelect() {
        System.out.println("Anda memilih " + getNama() + " dengan terminal asal " + getAsal() + " dan tujuan " + getTujuan());
        System.out.println("Harga tiket: " + Util.formatRupiah(getHargaTiket()));
        System.out.println("Yang akan berangkat pada " + getJadwalKeberangkatan());
    }
}
