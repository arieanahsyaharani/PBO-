public enum StepChange {
    CONFIRM, TANGGAL, NOMOR_KENDARAAN, DATA
}
