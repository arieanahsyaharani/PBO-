import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

class TicketSystem {
    JenisTransportasi jenisTransportasi = JenisTransportasi.NONE;
    private ArrayList<Transport> transports = new ArrayList<>();

    private Transport selectedTransport;
    ArrayList<Ticket> tickets = new ArrayList<>();

    public void addTransport(Transport transport) {
        transports.add(transport);
    }


    public void showAvailableTransports() throws IOException {
        for (Transport transport : transports) {
            if (transport instanceof Train && jenisTransportasi == JenisTransportasi.KERETA) {
                transport.displayInfo();
            }else if (transport instanceof Bus && jenisTransportasi == JenisTransportasi.BIS) {
                transport.displayInfo();
            }
            System.out.println();
        }
        System.out.print("Tekan tombol ENTER untuk kembali");
        System.in.read();
    }

    public void showAvailableTransports(String date) throws IOException {
        for (Transport transport : transports) {
            if (transport instanceof Train && transport.getJadwalKeberangkatan().substring(0, 10).equals(date) && jenisTransportasi == JenisTransportasi.KERETA) {
                transport.displayInfo();
            }else if (transport instanceof Bus && transport.getJadwalKeberangkatan().substring(0, 10).equals(date) && jenisTransportasi == JenisTransportasi.BIS) {
                transport.displayInfo();
            }
        }
    }

    public boolean checkAvailableTransports(String date) throws IOException {
        boolean isAvailable = false;
        for (Transport transport : transports) {
            if (transport instanceof Train && transport.getJadwalKeberangkatan().substring(0, 10).equals(date) && jenisTransportasi == JenisTransportasi.KERETA) {
                isAvailable = true;
            }else if (transport instanceof Bus && transport.getJadwalKeberangkatan().substring(0, 10).equals(date) && jenisTransportasi == JenisTransportasi.BIS) {
                isAvailable = true;
            }
        }
        return isAvailable;
    }

    public void selectKendaraan(String nomorKendaraan) {
        for (Transport transport : transports) {
            if (transport.getNomorKendaraan().equals(nomorKendaraan)) {
                selectedTransport = transport;
                transport.displaySelect();
            }
        }
    }

    public boolean checkKendaraan(String nomorKendaraan) {
        for (Transport transport : transports) {
            if (transport.getNomorKendaraan().equals(nomorKendaraan)) {
                return true;
            }
        }

        return false;
    }

    public String getHargaTiket(int quantity) {
        return Util.formatRupiah(selectedTransport.getHargaTiket() * quantity);
    }

    public Ticket buyTicket(String name, String address, String phoneNumber, String email, String rekening, int quantity,
            String date, String nomorKendaraan) {
        String ticketNo = String.valueOf(ThreadLocalRandom.current().nextInt(1_000_000, 10_000_000));
        Ticket ticket = new Ticket(ticketNo, name, address, phoneNumber, email, rekening, quantity, date, selectedTransport);
        tickets.add(ticket);
        return ticket;
    }

    public Ticket checkTicketNo(String ticketNo) throws Exception {
        Ticket foundTicket = null;
        for (Ticket ticket : tickets) {
            if (ticket.getTicketNo().equals(ticketNo)) {
                foundTicket = ticket;
            }
        }
        if (foundTicket != null) {
            if (foundTicket.isCetak) {
                throw new Exception("Tiket sudah dicetak");
            }
            return foundTicket;
        }
        return null;
    }

    public Ticket changeJadwal(String ticketNo, String date, String nomorKendaraan) {
        for (Ticket ticket : tickets) {
            if (ticket.getTicketNo().equals(ticketNo)) {
                ticket.setDate(date);
                for (Transport transport : transports) {
                    if (transport.getNomorKendaraan().equals(nomorKendaraan)) {
                        ticket.kendaraan = transport;
                    }
                }
            }
        }
        return null;
    }

    public void cancelTicket(String ticketNo) {
        for (Ticket ticket : tickets) {
            if (ticket.getTicketNo().equals(ticketNo)) {
                tickets.remove(ticket);
                return;
            }
        }
    }
}
