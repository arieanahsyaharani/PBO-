import java.io.IOException;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void clrscr() { 
        for (int i = 0; i < 99; i++) {
            System.out.println("\b");
        }
    }

    public static void loading() {
        int randomNum = ThreadLocalRandom.current().nextInt(1, 11); // jumlah iterasi acak antara 1 sampai 10
        String processString = "Memproses";
        for (int i = 0; i < randomNum; i++) {
            System.out.print("\r" + processString);
            processString += ".";
            try {
                Thread.sleep(500);  // durasi tetap 0,5 detik
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void main(String[] args) throws IOException {
        int choice = 0;
        Scanner scanner = new Scanner(System.in);
        JenisTransportasi pilihanJenis = JenisTransportasi.NONE;
        TicketSystem ticketSystem = new TicketSystem();
        
        Steps step = Steps.NEW;
        StepBuy stepBuy = StepBuy.TANGGAl;
        StepChange stepChange = StepChange.CONFIRM;

        String date = ""; 
        String nomorKendaraan = "";
        Ticket ticket = null;
        String ticketNo = "";

        // Nambahin data kendaraan
        ticketSystem.addTransport(new Train("Argo Parahyangan", 200, 50000, 300, "Jakarta", "Surabaya", "TR-0001", "2024-11-01 10:00", 120, "Ekonomi"));
        ticketSystem.addTransport(new Train("Argo Wilis", 200, 55000, 300, "Bandung", "Yogyakarta", "TR-0002", "2024-11-02 13:00", 180, "Ekonomi"));
        ticketSystem.addTransport(new Train("Taksaka", 200, 60000, 320, "Yogyakarta", "Jakarta", "TR-0003", "2024-11-02 16:00", 150, "Eksekutif"));
        ticketSystem.addTransport(new Train("Gajayana", 200, 65000, 280, "Malang", "Jakarta", "TR-0004", "2024-11-03 08:00", 360, "Eksekutif"));
        ticketSystem.addTransport(new Train("Lodaya", 200, 52000, 290, "Bandung", "Solo", "TR-0005", "2024-11-04 12:30", 240, "Ekonomi"));
        ticketSystem.addTransport(new Bus("Dewi Sri", 50, 50000, 100, "Jakarta", "Surabaya", "BS-0001", "2024-11-02 10:00", 120));
        ticketSystem.addTransport(new Bus("Rosalia Indah", 50, 40000, 120, "Bandung", "Surabaya", "BS-0002", "2024-11-03 11:30", 180));
        ticketSystem.addTransport(new Bus("Handoyo", 50, 45000, 150, "Jakarta", "Bandung", "BS-0003", "2024-11-03 14:00", 120));
        ticketSystem.addTransport(new Bus("Safari Dharma Raya", 50, 48000, 100, "Jakarta", "Solo", "BS-0004", "2024-11-04 18:00", 300));
        ticketSystem.addTransport(new Bus("Pahala Kencana", 50, 55000, 140, "Yogyakarta", "Malang", "BS-0005", "2024-11-04 07:00", 210));
        ticketSystem.addTransport(new Bus("Sinar Jaya", 50, 53000, 110, "Jakarta", "Semarang", "BS-0006", "2024-11-05 09:00", 250));




        while (true) {
            clrscr();

            if (pilihanJenis == JenisTransportasi.NONE) {
                System.out.println("1. Kereta");
                System.out.println("2. Bis");

                System.out.print("Pilih Jenis Transportasi (Masukan Nomor): ");
                String pilihan = scanner.nextLine();
                pilihanJenis = pilihan.equals("1") ? JenisTransportasi.KERETA : pilihan.equals("2") ? JenisTransportasi.BIS : JenisTransportasi.NONE;
                if (pilihanJenis == JenisTransportasi.NONE) {
                    System.err.print("Jenis Transportasi Tidak Tersedia, klik Enter untuk melanjutkan...");
                    scanner.nextLine();
                    continue;
                }
                ticketSystem.jenisTransportasi = pilihanJenis;
                clrscr();
                step = Steps.MENU;
            }

            if (step == Steps.NEW) {
                continue;
            }

            if (step == Steps.MENU) {
                System.out.println("--- E-Ticketing System (" + (pilihanJenis == JenisTransportasi.KERETA ? "Kereta" : "Bis") + ") ---");
                System.out.println("1. Cek Jadwal Transportasi");
                System.out.println("2. Beli Tiket");
                System.out.println("3. Cetak Tiket");
                System.out.println("4. Ganti Jadwal");
                System.out.println("5. Batalkan Tiket");
                System.out.println("6. Keluar");
                System.out.print("Select a menu option: ");
                choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        step = Steps.CHECK;
                        break;

                    case 2:
                        step = Steps.BUY;
                        break;

                    case 3:
                        step = Steps.PRINT;
                        break;

                    case 4:
                        step = Steps.CHANGE;
                        break;

                    case 5:
                        step = Steps.CANCEL;
                        break;

                    case 6:
                        step = Steps.NEW;
                        pilihanJenis = JenisTransportasi.NONE;
                        break;

                    default:
                        System.err.println("Pilihan tidak tersedia");
                        System.out.print("Tekan ENTER untuk melanjutkan...");
                        scanner.nextLine();
                        break;
                }
    
                clrscr();
            }


            try{
                switch (step) {
                    case Steps.CHECK:
                        System.out.println("Jadwal yang tersedia:");
                        ticketSystem.showAvailableTransports();
                        step = Steps.MENU;
                        break;
    
                    case Steps.BUY:
                        if (stepBuy == StepBuy.TANGGAl) {
                            System.out.println("isi x untuk kembali");
                            System.out.print("Masukan Tanggal keberangkatan (YYYY-MM-DD): ");
                            date = scanner.nextLine();
    
                            if (date.equals("x")) {
                                stepBuy = StepBuy.TANGGAl;
                                step = Steps.MENU;
                                break;
                            }
                            
                            clrscr();
        
                            System.out.println("Jadwal yang tersedia untuk tanggal " + date + ": ");
                            System.err.println();
                            boolean available = ticketSystem.checkAvailableTransports(date);
    
                            if (!available) {
                                System.err.println("Tidak ada jadwal yang tersedia untuk tanggal " + date);
                                System.out.print("Tekan ENTER untuk melanjutkan...");
                                scanner.nextLine();
                                break;
                            }else{
                                stepBuy = StepBuy.NOMOR_KENDARAAN;
                            }
                        }
    
                        if (stepBuy == StepBuy.NOMOR_KENDARAAN) {
                            clrscr();
                            ticketSystem.showAvailableTransports(date);
                            System.out.println("isi x untuk kembali");
                            System.out.print("Pilih nomor kendaraan: ");
                            nomorKendaraan = scanner.nextLine();
    
                            if (nomorKendaraan.equals("x")) {
                                stepBuy = StepBuy.TANGGAl;
                                break;
                            }
                            boolean found = ticketSystem.checkKendaraan(nomorKendaraan);
    
                            if (!found) {
                                clrscr();
                                System.err.println("Nomor kendaraan " + nomorKendaraan + " tidak ditemukan");
                                System.out.print("Tekan ENTER untuk melanjutkan...");
                                scanner.nextLine();
    
                                break;
                            }else{
                                stepBuy = StepBuy.DATA;
                                break;
                            }
                        }
    
                        if (stepBuy == StepBuy.DATA) {
                            clrscr();
                            ticketSystem.selectKendaraan(nomorKendaraan);
                            try {
                                System.out.println();
                                System.out.println("---- Data Pemesan ----");
                                
                                System.out.print("Nama: "); String name = scanner.nextLine();
                                System.out.print("Alamat: "); String address = scanner.nextLine();
                                System.out.print("Nomor Telepon: "); String phoneNumber = scanner.nextLine();
                                System.out.print("Email: "); String email = scanner.nextLine();
                                System.out.print("No Rekening (Untuk keperluan refund): "); String rekening = scanner.nextLine();
                                System.out.println();
                                System.out.println("---- Data Pesanan ----");
                                System.out.print("Jumlah tiket: "); int quantity = scanner.nextInt();
    
                                // System.out.println("Ringkasan pesanan: ");
                                
                                // System.out.println("Nomor Kendaraan: " + nomorKendaraan);
                                // System.out.println("Jadwal Keberangkatan: " + date);
                                // System.out.println("Jumlah tiket: " + quantity);
                                // System.out.println();
                                scanner.nextLine();
                                System.out.println("Total bayar: " + ticketSystem.getHargaTiket(quantity));
                                System.out.println();
                                System.out.print("Konfirmasi pemesanan ? (Y/N) :");  String confirm = scanner.nextLine();
    
                                if (!confirm.toLowerCase().equals("y")) {
                                    System.out.println("Pemesanan dibatalkan");
                                    System.out.print("Tekan ENTER untuk melanjutkan...");
                                    step = Steps.MENU;
                                    stepBuy = StepBuy.TANGGAl;
                                    scanner.nextLine();
                                    break;
                                }else{
                                    clrscr();
                                    loading();
                                    clrscr();
                                    
                                    ticket = ticketSystem.buyTicket(name, address, phoneNumber, email, rekening, quantity, date, nomorKendaraan);
                                    System.out.println("Pemesanan berhasil. Nomor tiket: " + ticket.getTicketNo());
                                    System.out.print("Tekan ENTER untuk melanjutkan...");
                                    step = Steps.MENU;
                                    stepBuy = StepBuy.TANGGAl;
                                    scanner.nextLine();
                                    break;
                                }
                            } catch (Exception e) {
                                System.err.println(e.getMessage());
                                System.out.println("Tekan ENTER untuk melanjutkan...");
                                scanner.nextLine();
                                break;
                            }
                        }
                        // ticketSystem.showTransportsName();
                        break;
                    case Steps.PRINT:
                        clrscr();
                        System.out.println("---- Cetak Tiket ----");
                        System.out.println();
    
                        System.out.println("isi x untuk kembali");
                        System.out.print("Masukan Nomor Tiket yang ingin dicetak: ");
                        ticketNo = scanner.nextLine();
    
                        if (ticketNo.equals("x")) {
                            step = Steps.MENU;
                            break;
                        }
    
                        clrscr();
    
                        ticket = ticketSystem.checkTicketNo(ticketNo);
                        if (ticket == null) {
                            System.err.println("Nomor tiket " + ticketNo + " tidak ditemukan");
                            System.out.print("Tekan ENTER untuk melanjutkan...");
                            scanner.nextLine();
                            break;
                        }else{
                            loading();
                            clrscr();
                            ticket.displayInfo();
                            ticket.isCetak = true;
                            System.out.println();
                            System.out.println("Tiket berhasil dicetak.");
                            System.out.print("Tekan ENTER untuk melanjutkan...");
                            scanner.nextLine();
                            step = Steps.MENU;
                            break;
                        }
                    case Steps.CHANGE:
                        clrscr();
                        if (stepChange == StepChange.CONFIRM) {
                            System.out.println("---- Ganti Jadwal ----");
                            System.out.println();
    
                            System.out.println("isi x untuk kembali");
                            System.out.print("Masukan Nomor Tiket: ");
                            ticketNo = scanner.nextLine();
    
                            if (ticketNo.equals("x")) {
                                step = Steps.MENU;
                                break;
                            }
    
                            ticket = ticketSystem.checkTicketNo(ticketNo);
                            if (ticket == null) {
                                System.err.println("Nomor tiket " + ticketNo + " tidak ditemukan");
                                System.out.print("Tekan ENTER untuk melanjutkan...");
                                scanner.nextLine();
                                break;
                            }else{
                                clrscr();
                                System.out.println("-- Detail Tiket --");
                                System.out.println();
                                System.out.println("Nomor Tiket: " + ticket.getTicketNo());
                                System.out.println("Pemesan: " + ticket.getName());
                                System.out.println("Asal: " + ticket.kendaraan.getAsal());
                                System.out.println("Tujuan: " + ticket.kendaraan.getTujuan());
                                System.out.println("Tanggal Keberangkatan: " + ticket.getDate());
                                System.out.println();
                                System.out.print("Tekan ENTER untuk melanjutkan...");
                                scanner.nextLine();
                                stepChange = StepChange.TANGGAL;
                                break;
                            }
                        }
    
                        if (stepChange == StepChange.TANGGAL) {
                            System.out.println("---- Ganti Jadwal ----");
                            System.out.println();
                            System.out.println("isi x untuk kembali");
                            System.out.print("Masukan Tanggal keberangkatan yang baru (YYYY-MM-DD): ");
                            date = scanner.nextLine();
    
                            if (date.equals("x")) {
                                stepChange = StepChange.CONFIRM;
                                step = Steps.MENU;
                                break;
                            }
                            
                            clrscr();
        
                            System.out.println("Jadwal yang tersedia untuk tanggal " + date + ": ");
                            System.err.println();
                            boolean available = ticketSystem.checkAvailableTransports(date);
    
                            if (!available) {
                                System.err.println("Tidak ada jadwal yang tersedia untuk tanggal " + date);
                                System.out.print("Tekan ENTER untuk melanjutkan...");
                                scanner.nextLine();
                                break;
                            }else{
                                stepChange = StepChange.NOMOR_KENDARAAN;
                            }
                        }
    
                        if (stepChange == StepChange.NOMOR_KENDARAAN) {
                            clrscr();
                            ticketSystem.showAvailableTransports(date);
                            System.out.println("isi x untuk kembali");
                            System.out.print("Pilih nomor kendaraan: ");
                            nomorKendaraan = scanner.nextLine();
    
                            if (nomorKendaraan.equals("x")) {
                                stepChange = StepChange.TANGGAL;
                                break;
                            }
                            boolean found = ticketSystem.checkKendaraan(nomorKendaraan);
    
                            if (!found) {
                                clrscr();
                                System.err.println("Nomor kendaraan " + nomorKendaraan + " tidak ditemukan");
                                System.out.print("Tekan ENTER untuk melanjutkan...");
                                scanner.nextLine();
    
                                break;
                            }else{
                                stepChange = StepChange.DATA;
                                break;
                            }
                        }
    
                        if (stepChange == StepChange.DATA) {
                            System.out.println("---- Ganti Jadwal ----");
                            System.out.println();
                            ticketSystem.selectKendaraan(nomorKendaraan);
                            System.out.println();
                            System.out.println("isi x untuk kembali");
                            System.out.print("Konfirmasi Ganti Jadwal? (Y/N) :");  String confirm = scanner.nextLine();
    
                            if (!confirm.toLowerCase().equals("y")) {
                                System.out.println("Ganti Jadwal dibatalkan");
                                System.out.print("Tekan ENTER untuk melanjutkan...");
                                step = Steps.MENU;
                                stepChange = StepChange.CONFIRM;
                                scanner.nextLine();
                                break;
                            }else{
                                clrscr();
                                loading();
                                clrscr();
                                
                                ticket = ticketSystem.changeJadwal(ticketNo, date, nomorKendaraan);
                                System.out.println("Jadwal berhasil diganti");
                                System.out.print("Tekan ENTER untuk melanjutkan...");
                                step = Steps.MENU;
                                stepChange = StepChange.CONFIRM;
                                scanner.nextLine();
                                break;
                            }
                        }
                        break;
                    case Steps.CANCEL:
                        System.out.println("---- Batalkan Ticket ----");
                        System.out.println();
                        System.out.println("isi x untuk kembali");
                        System.out.print("Nomor tiket yang ingin dibatalkan: ");
                        ticketNo = scanner.nextLine();
    
                        if (ticketNo.equals("x")) {
                            step = Steps.MENU;
                            break;
                        }
    
                        ticket = ticketSystem.checkTicketNo(ticketNo);
                        if (ticket == null) {
                            clrscr();
                            System.err.println("Nomor tiket " + ticketNo + " tidak ditemukan");
                            System.out.print("Tekan ENTER untuk melanjutkan...");
                            scanner.nextLine();
                            break;
                        }else{
                            clrscr();
                            loading();
                            clrscr();
                            ticketSystem.cancelTicket(ticketNo);
                            System.out.println("Tiket " + ticketNo + " dibatalkan, dana sebesar " + Util.formatRupiah(ticket.getQuantity() * ticket.kendaraan.getHargaTiket()) + " telah dikembalikan ke rekening " + ticket.getRekening());
                            System.out.print("Tekan ENTER untuk melanjutkan...");
                            scanner.nextLine();
                            step = Steps.MENU;
                            break;
                        }
                    default:
                        break;
                }
            }catch (Exception e) {
                clrscr();
                System.err.println(e.getMessage());
                System.out.print("Tekan ENTER untuk melanjutkan...");
                scanner.nextLine();
            }
        }
    }
}
