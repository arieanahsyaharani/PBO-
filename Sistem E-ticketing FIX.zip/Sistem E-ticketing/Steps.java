public enum Steps {
    NEW,
    MENU,
    BUY, CHECK, PRINT, CHANGE, CANCEL,
}
