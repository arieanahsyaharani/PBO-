import java.text.NumberFormat;
import java.util.Locale;

public class Util {
    public static String formatRupiah(double number) {
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        formatRupiah.setMaximumFractionDigits(0);

        return formatRupiah.format(number).replace("Rp", "Rp ");
    }
}
