public enum StepBuy {
    TANGGAl, NOMOR_KENDARAAN, DATA
}
