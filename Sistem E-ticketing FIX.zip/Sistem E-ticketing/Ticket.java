public class Ticket {
    String ticketNo;
    String name;
    String address;
    String phoneNumber;
    String email;
    String rekening;
    int quantity;
    String date;
    public boolean isCetak = false;
    Transport kendaraan;

    public Ticket(String ticketNo, String name, String address, String phoneNumber, String email, String rekening, int quantity, String date, Transport kendaraan) {
        this.ticketNo = ticketNo;
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.rekening = rekening;
        this.quantity = quantity;
        this.date = date;
        this.kendaraan = kendaraan;
    }

    public String getTicketNo() {
        return ticketNo;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {    
        return address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getRekening() {
        return rekening;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getDate() {
        return date;
    }

    public void displayInfo() {
        System.out.println("Nomor Tiket: " + getTicketNo());
        System.out.println(kendaraan.getNomorKendaraan() + " - " + kendaraan.getNama() + "( " + kendaraan.getAsal() + " -> " + kendaraan.getTujuan() + " )");
        System.out.println("Pemesan: " + getName());
        System.out.println("Alamat: " + getAddress());
        System.out.println("Nomor Telepon: " + getPhoneNumber());
        System.out.println("Email: " + getEmail());
        System.out.println("Nomor Rekening: " + getRekening());
        System.out.println("Jumlah Tiket: " + getQuantity());
        System.out.println("Tgl. Keberangkatan: " + getDate());
    }

    public void setDate(String date2) {
        this.date = date2;
    }
}
