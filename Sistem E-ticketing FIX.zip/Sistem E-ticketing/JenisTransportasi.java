public enum JenisTransportasi {
    KERETA, BIS, NONE
}