abstract class Transport {
    private String nama;
    private int kapasitas;
    private double hargaTiket;
    private int kecepatanMaksimum;
    private String asal;
    private String tujuan;
    private String nomorKendaraan;
    private String jadwalKeberangkatan;
    private int durasiPerjalanan;

    public Transport(String nama, int kapasitas, double hargaTiket, int kecepatanMaksimum, 
                     String asal, String tujuan, String nomorKendaraan, 
                     String jadwalKeberangkatan, int durasiPerjalanan) {
        this.nama = nama;
        this.kapasitas = kapasitas;
        this.hargaTiket = hargaTiket;
        this.kecepatanMaksimum = kecepatanMaksimum;
        this.asal = asal;
        this.tujuan = tujuan;
        this.nomorKendaraan = nomorKendaraan;
        this.jadwalKeberangkatan = jadwalKeberangkatan;
        this.durasiPerjalanan = durasiPerjalanan;
    }
    
    public String getNama() { return nama; }
    public int getKapasitas() { return kapasitas; }
    public double getHargaTiket() { return hargaTiket; }
    public int getKecepatanMaksimum() { return kecepatanMaksimum; }
    public String getAsal() { return asal; }
    public String getTujuan() { return tujuan; }
    public String getNomorKendaraan() { return nomorKendaraan; }
    public String getJadwalKeberangkatan() { return jadwalKeberangkatan; }
    public int getDurasiPerjalanan() { return durasiPerjalanan; }

    // Abstract method untuk menampilkan detail transportasi
    public abstract void displayInfoDetail();

    public abstract void displayInfo();

    public abstract void displaySelect();
}
