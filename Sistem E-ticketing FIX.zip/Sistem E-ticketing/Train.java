// Kelas Train yang mewarisi dari Transport
class Train extends Transport {
    String kelas;
    
    public Train(String name, int kapasitas, double hargaTiket, int kecepatanMaksimum, String asal, String tujuan, String nomorKendaraan, String jadwalKeberangkatan, int durasiPerjalanan, String kelas) {
        super(name, kapasitas, hargaTiket, kecepatanMaksimum, asal, tujuan, nomorKendaraan, jadwalKeberangkatan, durasiPerjalanan);
        this.kelas = kelas;
    }

    // Implementasi dari abstract method di Transport
    @Override
    public void displayInfoDetail() {
        System.out.println("Nama Kereta: " + getNama());
        System.out.println("Kelas: " + kelas);
        System.out.println("Kapasitas: " + getKapasitas() + " Penumpang");
        System.out.println("Harga Tiket: " + Util.formatRupiah(getHargaTiket()));
        System.out.println("Kecepatan Maksimum: " + getKecepatanMaksimum() + " km/h");
        System.out.println("Asal: " + getAsal());
        System.out.println("Tujuan: " + getTujuan());
        System.out.println("Nomor Kendaraan: " + getNomorKendaraan());
        System.out.println("Jadwal Keberangkatan: " + getJadwalKeberangkatan());
        System.out.println("Durasi Perjalanan: " + getDurasiPerjalanan() + " menit");
    }

    @Override
    public void displayInfo() {
        System.out.println("Nomor Kendaraan: " + getNomorKendaraan());
        System.out.println(getNama() + " - " + kelas + " (" + Util.formatRupiah(getHargaTiket()) + ")");
        System.err.println(getAsal() + " -> " + getTujuan());
        System.out.println("Berangkat pada " + getJadwalKeberangkatan());
        System.out.println();
    }

    @Override
    public void displaySelect() {
        System.out.println("Anda memilih " + getNama() + "(" + kelas + ") dengan stasiun asal " + getAsal() + " dan tujuan " + getTujuan());
        System.out.println("Harga tiket: " + Util.formatRupiah(getHargaTiket()));
        System.out.println("Yang akan berangkat pada " + getJadwalKeberangkatan());
    }
}
